#import <React/RCTBridgeModule.h>

@interface ShopSdk : NSObject <RCTBridgeModule>

@end
