//
//  BannerHandler.h
//  sdk-advertise
//
//  Created by ta.cao.thanh on 9/15/18.
//  Copyright © 2018 Rabiloo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BannerHandler : NSObject

+ (void)showBannerWithData:(NSDictionary*)data;

@end
