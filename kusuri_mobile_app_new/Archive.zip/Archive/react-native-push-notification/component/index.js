// Define suffix-less index module for unit tests
module.exports = {
  state: {},
  component: {}
};
