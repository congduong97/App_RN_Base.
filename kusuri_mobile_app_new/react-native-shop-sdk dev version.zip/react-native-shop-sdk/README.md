# react-native-shop-sdk

## Getting started

`$ npm install react-native-shop-sdk --save`

### Mostly automatic installation

`$ react-native link react-native-shop-sdk`

## Usage
```javascript
import ShopSdk from 'react-native-shop-sdk';

// TODO: What to do with the module?
ShopSdk;
```
