
import { NativeModules } from 'react-native';
import ReactBanner from './banner/ReactBanner';
import {RNShopSDKWebLink} from './weblink/RNShopSDKWebLink';

const { RNShopSdk } = NativeModules;

  const RNShopSdkBanner= RNShopSdk;
export  {RNShopSdkBanner,RNShopSDKWebLink,ReactBanner};
