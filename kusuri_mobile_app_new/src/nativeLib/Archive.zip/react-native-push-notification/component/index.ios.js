'use strict';

import {
  AppState,
  PushNotificationIOS
} from 'react-native';

module.exports = {
  state: AppState,
  component: PushNotificationIOS
};

