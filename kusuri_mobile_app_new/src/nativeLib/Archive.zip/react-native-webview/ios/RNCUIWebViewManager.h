#import <React/RCTViewManager.h>

@interface RNCUIWebViewManager : RCTViewManager

@end
