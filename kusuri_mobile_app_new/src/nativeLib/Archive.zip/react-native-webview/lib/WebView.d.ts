import { WebView } from 'react-native';
export { WebView };
export default WebView;
//# sourceMappingURL=WebView.d.ts.map