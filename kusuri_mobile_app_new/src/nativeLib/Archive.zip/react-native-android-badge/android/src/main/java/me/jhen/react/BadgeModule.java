package me.jhen.react;

import android.content.Context;
import android.content.SharedPreferences;

import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import me.leolin.shortcutbadger.ShortcutBadger;

public class BadgeModule extends ReactContextBaseJavaModule {

  private Context context;
  private static final String LAUNCHER_BADGE = "LAUNCHER_BADGE";
  private static final String CURRENT_BADGE = "CURRENT_BADGE";
  private int getCacheCurrentLauncherBadge(Context ctx) {
    SharedPreferences settings = ctx.getSharedPreferences(LAUNCHER_BADGE, Context.MODE_PRIVATE);
    return settings.getInt(CURRENT_BADGE, 0);
  }
  private void setCacheCurrentLauncherBadge(Context ctx, int badgeCount) {
    SharedPreferences settings = ctx.getSharedPreferences(LAUNCHER_BADGE, Context.MODE_PRIVATE);
    SharedPreferences.Editor editor = settings.edit();

    editor.putInt(CURRENT_BADGE, badgeCount);
    editor.apply();
  }

  public BadgeModule(ReactApplicationContext reactContext) {
    super(reactContext);

    this.context = (Context) reactContext;
  }

  @Override
  public String getName() {
    return "BadgeAndroid";
  }

  @ReactMethod
  public void setBadge(int number) {
    ShortcutBadger.applyCount(getReactApplicationContext(), number);
    setCacheCurrentLauncherBadge(getReactApplicationContext(),number);
  }
}