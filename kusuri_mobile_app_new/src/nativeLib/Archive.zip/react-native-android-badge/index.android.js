var { NativeModules } = require('react-native');
module.exports = NativeModules.BadgeAndroid;